def ounces_to_grams(weight):
    new_weight = weight * 28.3495
    return new_weight
